#!/usr/bin/env python3
"""
Application Health Checker
==========================
A production-quality utility that checks the availability of web
endpoints, measures response times, reports UP / DOWN status, and
optionally runs in continuous mode.

Dependencies:
    pip install requests

Usage:
    python app_health_checker.py
    python app_health_checker.py --urls https://example.com https://google.com
    python app_health_checker.py --continuous --interval 30 --timeout 10
"""

import argparse
import logging
import os
import sys
import time
from datetime import datetime

try:
    import requests
    from requests.exceptions import (
        ConnectionError as ReqConnectionError,
        HTTPError,
        SSLError,
        Timeout,
        TooManyRedirects,
    )
except ImportError:
    print(
        "❌  Missing dependency: requests\n"
        "   Install it with:  pip install requests"
    )
    sys.exit(1)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DEFAULT_TIMEOUT = 10            # seconds per request
DEFAULT_INTERVAL = 30           # seconds between continuous rounds
LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uptime.log")

DEFAULT_URLS = [
    "https://opensource-demo.orangehrmlive.com",
    "https://www.google.com",
]

BANNER = r"""
╔══════════════════════════════════════════════════╗
║        🌐  Application Health Checker  🌐        ║
╠══════════════════════════════════════════════════╣
║  Checks endpoint availability & response times   ║
╚══════════════════════════════════════════════════╝
"""

# ---------------------------------------------------------------------------
# Logging setup – file handler only (console output is handled manually)
# ---------------------------------------------------------------------------

def _get_file_logger() -> logging.Logger:
    """Return a logger that appends every result line to *uptime.log*."""
    logger = logging.getLogger("app_health_checker")
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
        fh.setLevel(logging.INFO)
        fh.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(fh)
    return logger


file_logger = _get_file_logger()

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _timestamp() -> str:
    """Return a formatted timestamp string for the current moment."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _print_separator() -> None:
    """Print a thin visual separator."""
    print("─" * 90)

# ---------------------------------------------------------------------------
# Core check function
# ---------------------------------------------------------------------------

def check_url(url: str, timeout: int = DEFAULT_TIMEOUT) -> dict:
    """
    Send an HTTP GET to *url* and return a result dict.

    Keys returned:
        url          – the checked URL
        status_code  – HTTP status code or ``"N/A"``
        response_ms  – response time in milliseconds or ``"N/A"``
        is_up        – True if status code is 200
        error        – short error description (empty string if none)
        line         – pre-formatted log/console line
    """
    ts = _timestamp()
    result: dict = {
        "url": url,
        "status_code": "N/A",
        "response_ms": "N/A",
        "is_up": False,
        "error": "",
        "line": "",
    }

    try:
        resp = requests.get(url, timeout=timeout, allow_redirects=True)
        elapsed_ms = int(resp.elapsed.total_seconds() * 1000)
        result["status_code"] = resp.status_code
        result["response_ms"] = elapsed_ms
        result["is_up"] = resp.status_code == 200

    except Timeout:
        result["error"] = f"Timeout after {timeout}s"
    except SSLError as exc:
        result["error"] = f"SSL Error: {exc}"
    except ReqConnectionError:
        result["error"] = "Connection refused / DNS failure"
    except TooManyRedirects:
        result["error"] = "Too many redirects"
    except HTTPError as exc:
        result["error"] = f"HTTP Error: {exc}"
    except Exception as exc:                       # noqa: BLE001
        result["error"] = f"Unexpected error: {exc}"

    # Build the formatted output line
    status_icon = "✅" if result["is_up"] else "❌"
    status_text = "UP" if result["is_up"] else "DOWN"

    resp_time_str = (
        f"{result['response_ms']}ms"
        if result["response_ms"] != "N/A"
        else "N/A"
    )

    line = (
        f"[{ts}] URL: {url} | "
        f"Status: {result['status_code']} | "
        f"Response Time: {resp_time_str} | "
        f"Status: {status_text} {status_icon}"
    )

    if result["error"]:
        line += f" | Error: {result['error']}"

    result["line"] = line
    return result

# ---------------------------------------------------------------------------
# Summary helpers
# ---------------------------------------------------------------------------

def _print_summary(results: list[dict]) -> None:
    """Print a compact summary table after a check round."""
    up_count = sum(1 for r in results if r["is_up"])
    down_count = len(results) - up_count

    print()
    _print_separator()
    print(
        f"📈  Summary: {up_count} UP  |  {down_count} DOWN  |  "
        f"{len(results)} Total"
    )
    _print_separator()

# ---------------------------------------------------------------------------
# Main orchestration
# ---------------------------------------------------------------------------

def run_health_checks(urls: list[str], timeout: int) -> list[dict]:
    """
    Check every URL in *urls* and return the list of result dicts.

    Results are printed to the console and logged to *uptime.log*.
    """
    ts = _timestamp()
    print(f"\n🕐  Health Check at {ts}")
    _print_separator()

    results: list[dict] = []
    for url in urls:
        result = check_url(url, timeout=timeout)
        print(result["line"])
        file_logger.info(result["line"])
        results.append(result)

    _print_summary(results)
    return results


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse and return command-line arguments."""
    parser = argparse.ArgumentParser(
        description="🌐  Application Health Checker — ping endpoints and measure uptime.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--urls", "-u",
        nargs="+",
        default=DEFAULT_URLS,
        metavar="URL",
        help=(
            "One or more URLs to check "
            f"(default: {', '.join(DEFAULT_URLS)})"
        ),
    )
    parser.add_argument(
        "--timeout", "-t",
        type=int,
        default=DEFAULT_TIMEOUT,
        metavar="SEC",
        help=f"Request timeout in seconds (default: {DEFAULT_TIMEOUT}s)",
    )
    parser.add_argument(
        "--interval", "-i",
        type=int,
        default=DEFAULT_INTERVAL,
        metavar="SEC",
        help=f"Seconds between rounds in continuous mode (default: {DEFAULT_INTERVAL}s)",
    )
    parser.add_argument(
        "--continuous", "-c",
        action="store_true",
        help="Run continuously until interrupted (Ctrl+C to stop)",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    """Entry-point for the Application Health Checker."""
    args = parse_args(argv)

    print(BANNER)
    print(f"  URLs      : {len(args.urls)} endpoint(s)")
    for url in args.urls:
        print(f"              → {url}")
    print(f"  Timeout   : {args.timeout}s")
    print(f"  Interval  : {args.interval}s")
    print(f"  Mode      : {'Continuous' if args.continuous else 'Single run'}")
    print(f"  Log file  : {LOG_FILE}")
    _print_separator()

    if args.continuous:
        print("\n🔄  Continuous mode — press Ctrl+C to stop.\n")
        try:
            while True:
                run_health_checks(args.urls, args.timeout)
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n\n👋  Monitoring stopped by user. Goodbye!")
    else:
        run_health_checks(args.urls, args.timeout)
        print(f"\n✅  Single check complete. Results saved to {LOG_FILE}")


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    main()
