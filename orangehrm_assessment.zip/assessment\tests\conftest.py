"""
Conftest - Shared Pytest fixtures for OrangeHRM test suite.

This module provides:
- Browser and page setup
- Login fixtures
- Page object fixtures
- Test data generation
"""

import time
import pytest
from pages.login_page import LoginPage
from pages.admin_page import AdminPage


# ── Constants ────────────────────────────────────────────────────────────

BASE_URL = "https://opensource-demo.orangehrmlive.com"
ADMIN_USERNAME = "Admin"
ADMIN_PASSWORD = "admin123"


# ── Test Data ────────────────────────────────────────────────────────────

def generate_unique_username(prefix: str = "TestUser") -> str:
    """
    Generate a unique username using a timestamp to avoid
    collisions on the shared demo site.

    Args:
        prefix: Username prefix

    Returns:
        A unique username like 'TestUser_1718345678'
    """
    return f"{prefix}_{int(time.time())}"


# ── Fixtures ─────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def browser_context_args(browser_context_args):
    """Configure the browser context with a larger viewport and timeouts."""
    return {
        **browser_context_args,
        "viewport": {"width": 1920, "height": 1080},
        "ignore_https_errors": True,
    }


@pytest.fixture(scope="function")
def login_page(page):
    """
    Provide a LoginPage instance.

    Args:
        page: Playwright page from pytest-playwright

    Returns:
        LoginPage instance
    """
    return LoginPage(page)


@pytest.fixture(scope="function")
def admin_page(page):
    """
    Provide an AdminPage instance.

    Args:
        page: Playwright page from pytest-playwright

    Returns:
        AdminPage instance
    """
    return AdminPage(page)


@pytest.fixture(scope="function")
def logged_in_page(page, login_page):
    """
    Provide a page that is already logged in as Admin.
    Navigates to login and authenticates before returning the page.

    Args:
        page: Playwright page from pytest-playwright
        login_page: LoginPage fixture

    Returns:
        Playwright page object (logged in)
    """
    login_page.navigate()
    login_page.login(ADMIN_USERNAME, ADMIN_PASSWORD)
    login_page.is_login_successful()
    return page


@pytest.fixture(scope="function")
def admin_logged_in(logged_in_page, admin_page):
    """
    Provide an AdminPage that is logged in and navigated to the Admin section.

    Args:
        logged_in_page: Page that is already logged in
        admin_page: AdminPage fixture

    Returns:
        AdminPage instance on the Admin page
    """
    admin_page.navigate()
    return admin_page


@pytest.fixture(scope="function")
def test_username():
    """
    Generate a unique test username for user creation tests.

    Returns:
        A unique username string
    """
    return generate_unique_username("TestUser")


@pytest.fixture(scope="function")
def edited_username():
    """
    Generate a unique edited username for user edit tests.

    Returns:
        A unique username string with 'Edited' prefix
    """
    return generate_unique_username("EditedUser")


@pytest.fixture(scope="function")
def test_password():
    """
    Provide a test password that meets OrangeHRM requirements.

    Returns:
        A valid password string
    """
    return "Test@12345"
