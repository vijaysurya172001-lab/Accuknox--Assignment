"""
Test User Management - E2E Test Suite for OrangeHRM User Management Module.

This test suite covers the complete CRUD (Create, Read, Update, Delete)
lifecycle for user management on the OrangeHRM demo site.

Test Cases:
    TC_001: test_valid_login
    TC_002: test_navigate_to_admin
    TC_003: test_add_new_user
    TC_004: test_search_user_by_username
    TC_005: test_verify_searched_user_details
    TC_006: test_edit_user_details
    TC_007: test_validate_updated_details
    TC_008: test_delete_user

Note: Tests are ordered and depend on shared state via class-level variables
      because they represent a sequential E2E workflow on a shared demo site.
"""

import time
import pytest
from pages.login_page import LoginPage
from pages.admin_page import AdminPage


# ── Constants ────────────────────────────────────────────────────────────

BASE_URL = "https://opensource-demo.orangehrmlive.com"
ADMIN_USERNAME = "Admin"
ADMIN_PASSWORD = "admin123"
TEST_PASSWORD = "Test@12345"
EDITED_PASSWORD = "Edited@12345"


class TestUserManagement:
    """
    End-to-End test class for OrangeHRM User Management.

    Tests run in order and share state (usernames) across methods
    to simulate a complete user lifecycle.
    """

    # Shared state across test methods
    test_username = f"TestUser_{int(time.time())}"
    edited_username = f"EditedUser_{int(time.time())}"

    # ── TC_001: Valid Login ───────────────────────────────────────────────

    def test_valid_login(self, page):
        """
        TC_001: Verify successful login to OrangeHRM with valid credentials.

        Steps:
            1. Navigate to the OrangeHRM login page
            2. Enter valid username 'Admin'
            3. Enter valid password 'admin123'
            4. Click the Login button

        Expected Result:
            - User is redirected to the Dashboard page
            - Dashboard heading is visible
        """
        login_page = LoginPage(page)
        login_page.navigate()

        # Verify we are on the login page
        assert login_page.is_on_login_page(), "Login page did not load properly"

        # Perform login
        login_page.login(ADMIN_USERNAME, ADMIN_PASSWORD)

        # Verify successful login
        assert login_page.is_login_successful(), "Login failed — Dashboard not visible"
        assert "dashboard" in page.url.lower(), "URL does not contain 'dashboard'"

    # ── TC_002: Navigate to Admin Module ─────────────────────────────────

    def test_navigate_to_admin(self, page):
        """
        TC_002: Verify navigation to the Admin module from Dashboard.

        Pre-conditions:
            - User is logged in as Admin

        Steps:
            1. Click on the 'Admin' menu item in the sidebar
            2. Wait for the Admin page to load

        Expected Result:
            - Admin page loads with System Users section visible
            - URL contains '/admin/viewSystemUsers'
        """
        # Login first
        login_page = LoginPage(page)
        login_page.navigate()
        login_page.login(ADMIN_USERNAME, ADMIN_PASSWORD)
        login_page.is_login_successful()

        # Navigate to Admin
        admin_page = AdminPage(page)
        admin_page.navigate()

        # Verify Admin page loaded
        assert admin_page.is_on_admin_page(), "Admin page did not load"
        assert "viewSystemUsers" in page.url, "URL does not contain 'viewSystemUsers'"

    # ── TC_003: Add a New User ───────────────────────────────────────────

    def test_add_new_user(self, page):
        """
        TC_003: Verify adding a new user through the Admin panel.

        Pre-conditions:
            - User is logged in as Admin
            - User is on the Admin > User Management page

        Steps:
            1. Click the '+ Add' button
            2. Select 'Admin' as User Role
            3. Enter an employee name and select from autocomplete
            4. Select 'Enabled' as Status
            5. Enter a unique username
            6. Enter password and confirm password
            7. Click Save

        Expected Result:
            - Success toast message appears
            - User is saved to the system
        """
        # Login and navigate to Admin
        login_page = LoginPage(page)
        login_page.navigate()
        login_page.login(ADMIN_USERNAME, ADMIN_PASSWORD)
        login_page.is_login_successful()

        admin_page = AdminPage(page)
        admin_page.navigate()

        # Add new user
        admin_page.add_user(
            user_role="Admin",
            employee_name="a",  # Type 'a' to trigger autocomplete with any employee
            status="Enabled",
            username=self.test_username,
            password=TEST_PASSWORD,
        )

        # Verify success toast
        assert admin_page.wait_for_success_toast(), (
            "Success toast did not appear after adding user"
        )

    # ── TC_004: Search for the Newly Created User ────────────────────────

    def test_search_user_by_username(self, page):
        """
        TC_004: Verify searching for a user by username returns correct results.

        Pre-conditions:
            - User is logged in as Admin
            - A test user has been created (TC_003)
            - User is on the Admin page

        Steps:
            1. Enter the test username in the search field
            2. Click the Search button
            3. Wait for results to load

        Expected Result:
            - At least one record is found
            - The search results table displays the matching user
        """
        # Login and navigate to Admin
        login_page = LoginPage(page)
        login_page.navigate()
        login_page.login(ADMIN_USERNAME, ADMIN_PASSWORD)
        login_page.is_login_successful()

        admin_page = AdminPage(page)
        admin_page.navigate()

        # Search for the user
        admin_page.search_user(self.test_username)

        # Verify search results
        result_count = admin_page.get_search_results_count()
        assert result_count >= 1, (
            f"Expected at least 1 result for '{self.test_username}', got {result_count}"
        )

    # ── TC_005: Verify Searched User Details ─────────────────────────────

    def test_verify_searched_user_details(self, page):
        """
        TC_005: Verify the searched user's details match what was created.

        Pre-conditions:
            - User is logged in as Admin
            - Search has been performed for the test user (TC_004)

        Steps:
            1. Search for the test user
            2. Read the first row's data from the results table
            3. Verify username, role, and status match

        Expected Result:
            - Username matches the created username
            - User Role shows 'Admin'
            - Status shows 'Enabled'
        """
        # Login and navigate to Admin
        login_page = LoginPage(page)
        login_page.navigate()
        login_page.login(ADMIN_USERNAME, ADMIN_PASSWORD)
        login_page.is_login_successful()

        admin_page = AdminPage(page)
        admin_page.navigate()

        # Search and verify details
        admin_page.search_user(self.test_username)

        user_data = admin_page.get_first_user_data()

        assert user_data["username"] == self.test_username, (
            f"Username mismatch: expected '{self.test_username}', "
            f"got '{user_data['username']}'"
        )
        assert user_data["user_role"] == "Admin", (
            f"Role mismatch: expected 'Admin', got '{user_data['user_role']}'"
        )
        assert user_data["status"] == "Enabled", (
            f"Status mismatch: expected 'Enabled', got '{user_data['status']}'"
        )

    # ── TC_006: Edit User Details ────────────────────────────────────────

    def test_edit_user_details(self, page):
        """
        TC_006: Verify editing all possible user details.

        Pre-conditions:
            - User is logged in as Admin
            - The test user exists in the system

        Steps:
            1. Search for the test user
            2. Click the Edit button on their row
            3. Change User Role to 'ESS'
            4. Change Status to 'Disabled'
            5. Change Username to a new value
            6. Change Password
            7. Click Save

        Expected Result:
            - Success toast message 'Successfully Updated' appears
            - Changes are saved
        """
        # Login and navigate to Admin
        login_page = LoginPage(page)
        login_page.navigate()
        login_page.login(ADMIN_USERNAME, ADMIN_PASSWORD)
        login_page.is_login_successful()

        admin_page = AdminPage(page)
        admin_page.navigate()

        # Search for the user and click edit
        admin_page.search_user(self.test_username)
        admin_page.click_edit_button(row_index=0)

        # Edit user details
        admin_page.edit_user(
            new_user_role="ESS",
            new_status="Disabled",
            new_username=self.edited_username,
            new_password=EDITED_PASSWORD,
        )

        # Verify success toast
        assert admin_page.wait_for_success_toast(), (
            "Success toast did not appear after editing user"
        )

    # ── TC_007: Validate Updated Details ─────────────────────────────────

    def test_validate_updated_details(self, page):
        """
        TC_007: Verify the edited user details were saved correctly.

        Pre-conditions:
            - User is logged in as Admin
            - User details have been edited (TC_006)

        Steps:
            1. Search for the user using the NEW username
            2. Verify updated User Role is 'ESS'
            3. Verify updated Status is 'Disabled'

        Expected Result:
            - Search finds the user with the new username
            - User Role displays 'ESS'
            - Status displays 'Disabled'
        """
        # Login and navigate to Admin
        login_page = LoginPage(page)
        login_page.navigate()
        login_page.login(ADMIN_USERNAME, ADMIN_PASSWORD)
        login_page.is_login_successful()

        admin_page = AdminPage(page)
        admin_page.navigate()

        # Search with the edited username
        admin_page.search_user(self.edited_username)

        # Verify updated details
        result_count = admin_page.get_search_results_count()
        assert result_count >= 1, (
            f"No results found for edited username '{self.edited_username}'"
        )

        user_data = admin_page.get_first_user_data()

        assert user_data["username"] == self.edited_username, (
            f"Username mismatch: expected '{self.edited_username}', "
            f"got '{user_data['username']}'"
        )
        assert user_data["user_role"] == "ESS", (
            f"Role not updated: expected 'ESS', got '{user_data['user_role']}'"
        )
        assert user_data["status"] == "Disabled", (
            f"Status not updated: expected 'Disabled', got '{user_data['status']}'"
        )

    # ── TC_008: Delete the User ──────────────────────────────────────────

    def test_delete_user(self, page):
        """
        TC_008: Verify deleting a user and confirming the deletion.

        Pre-conditions:
            - User is logged in as Admin
            - The edited test user exists in the system

        Steps:
            1. Search for the user using the edited username
            2. Click the Delete (trash) icon
            3. Confirm deletion in the dialog
            4. Search for the deleted user again
            5. Verify no records are found

        Expected Result:
            - Success toast message appears
            - User is removed from the system
            - Searching again returns 'No Records Found'
        """
        # Login and navigate to Admin
        login_page = LoginPage(page)
        login_page.navigate()
        login_page.login(ADMIN_USERNAME, ADMIN_PASSWORD)
        login_page.is_login_successful()

        admin_page = AdminPage(page)
        admin_page.navigate()

        # Search for the user to delete
        admin_page.search_user(self.edited_username)

        # Delete the user
        admin_page.delete_user(row_index=0)

        # Verify success toast
        assert admin_page.wait_for_success_toast(), (
            "Success toast did not appear after deleting user"
        )

        # Wait for the page to settle
        page.wait_for_timeout(2000)

        # Search again to confirm deletion
        admin_page.search_user(self.edited_username)

        # Verify no records found
        assert admin_page.is_no_records_found(), (
            f"User '{self.edited_username}' still found after deletion"
        )
