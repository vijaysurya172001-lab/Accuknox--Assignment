# 🧪 OrangeHRM QA Automation Suite

> **AccuKnox QA Trainee — Technical Assessment**  
> Automated E2E tests for OrangeHRM User Management module + Utility Scripts

---

## 📋 Project Overview

This repository contains:

1. **Manual Test Cases** — 8 detailed test cases in CSV format for the OrangeHRM User Management module
2. **Playwright Automation** — Python-based automated tests using the Page Object Model (POM) design pattern
3. **Utility Scripts** — System Health Monitor & Application Health Checker

### Application Under Test

| Property | Value |
|----------|-------|
| **URL** | https://opensource-demo.orangehrmlive.com |
| **Credentials** | `Admin` / `admin123` |
| **Module Tested** | Admin → User Management |

---

## 🏗️ Project Structure

```
assessment/
├── pages/                          # Page Object Model classes
│   ├── __init__.py
│   ├── login_page.py               # Login page interactions
│   └── admin_page.py               # Admin/User Management interactions
├── tests/                          # Pytest test suite
│   ├── __init__.py
│   ├── conftest.py                 # Shared fixtures & test config
│   └── test_user_management.py     # 8 E2E test cases
├── test_cases/
│   └── manual_test_cases.csv       # Manual test case spreadsheet
├── utils/                          # Utility scripts
│   ├── system_health_monitor.py    # CPU/Memory/Disk monitoring
│   └── app_health_checker.py       # URL uptime checker
├── requirements.txt                # Python dependencies
├── pytest.ini                      # Pytest configuration
├── README.md                       # This file
└── .gitignore
```

---

## 🔧 Prerequisites

- **Python** 3.10 or higher
- **pip** (Python package manager)
- **Node.js** (required by Playwright for browser binaries)
- **Git**

---

## 🚀 Setup Instructions

### 1. Clone the Repository

```bash
git clone https://github.com/<your-username>/orangehrm-qa-automation.git
cd orangehrm-qa-automation
```

### 2. Create a Virtual Environment (Recommended)

```bash
# Create virtual environment
python -m venv venv

# Activate it
# On Windows:
venv\Scripts\activate
# On Linux/Mac:
source venv/bin/activate
```

### 3. Install Python Dependencies

```bash
pip install -r requirements.txt
```

### 4. Install Playwright Browsers

```bash
playwright install chromium
```

---

## ▶️ Running the Tests

### Run All Tests (Headed Mode — Default)

```bash
pytest
```

### Run All Tests (Headless Mode — for CI/CD)

```bash
pytest --headed false
```

### Run a Specific Test

```bash
pytest tests/test_user_management.py::TestUserManagement::test_valid_login
```

### Run with Verbose Output

```bash
pytest -v
```

### Run with HTML Report

```bash
pip install pytest-html
pytest --html=report.html --self-contained-html
```

---

## 🧪 Test Cases

| ID | Test Case | Description |
|----|-----------|-------------|
| TC_001 | `test_valid_login` | Login with valid Admin credentials |
| TC_002 | `test_navigate_to_admin` | Navigate to Admin module from Dashboard |
| TC_003 | `test_add_new_user` | Add a new user with all required fields |
| TC_004 | `test_search_user_by_username` | Search for the newly created user |
| TC_005 | `test_verify_searched_user_details` | Verify searched user's role, status, and name |
| TC_006 | `test_edit_user_details` | Edit user role, status, username, and password |
| TC_007 | `test_validate_updated_details` | Confirm edited details are saved correctly |
| TC_008 | `test_delete_user` | Delete user and verify removal |

---

## 🛠️ Utility Scripts

### System Health Monitor

Monitors CPU, Memory, and Disk usage with threshold-based alerts.

```bash
# Run a one-time health check
python utils/system_health_monitor.py

# Run with custom threshold (default: 80%)
python utils/system_health_monitor.py --threshold 70

# Run in continuous monitoring mode
python utils/system_health_monitor.py --continuous --interval 10
```

### Application Health Checker

Checks the uptime and response time of web applications.

```bash
# Check default URLs
python utils/app_health_checker.py

# Check specific URLs
python utils/app_health_checker.py --urls https://google.com https://github.com

# Run in continuous monitoring mode
python utils/app_health_checker.py --continuous --interval 30
```

---

## 📦 Tech Stack & Versions

| Tool | Version | Purpose |
|------|---------|---------|
| Python | 3.10+ | Programming language |
| Playwright | ≥ 1.40.0 | Browser automation framework |
| pytest | ≥ 7.4.0 | Testing framework |
| pytest-playwright | ≥ 0.4.3 | Playwright integration for pytest |
| psutil | ≥ 5.9.0 | System monitoring (utility script) |
| requests | ≥ 2.31.0 | HTTP client (utility script) |

---

## 📝 Design Decisions

### Page Object Model (POM)

The test suite uses the POM design pattern to:
- **Separate concerns** — Page interactions are isolated from test logic
- **Improve maintainability** — Selector changes only need updates in one place
- **Enhance readability** — Tests read like user stories

### Selector Strategy

We use robust selectors that are resilient to UI changes:
- **Label-based filtering**: `page.locator("div.oxd-input-group").filter(has_text="Username")`
- **Semantic selectors**: `page.locator("button", has_text="Save")`
- **Class-based**: `.oxd-table-row`, `.oxd-toast--success` (OrangeHRM's component library)

### Test Independence

Each test function performs its own login to ensure tests can run independently, even though they share a test class for the E2E workflow.

---

## ⚠️ Known Limitations

1. **Shared Demo Site** — `opensource-demo.orangehrmlive.com` is shared by many users worldwide. Test usernames include timestamps to avoid collisions.
2. **Data Resets** — The demo site periodically resets all data. Tests are designed to create and clean up their own test data within a single session.
3. **Employee Name Autocomplete** — The autocomplete field requires typing and selecting from a dropdown, which can be flaky under load.

---

## 📄 License

This project is created as part of a technical assessment for AccuKnox.
