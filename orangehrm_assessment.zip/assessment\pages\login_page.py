"""
LoginPage - Page Object Model for OrangeHRM Login Page.

Handles all interactions with the login page including:
- Navigation to the login URL
- Entering credentials
- Submitting the login form
- Verifying successful/failed login
"""


class LoginPage:
    """Page Object for the OrangeHRM Login Page."""

    # ── URL ──────────────────────────────────────────────────────────────
    URL = "/web/index.php/auth/login"

    def __init__(self, page):
        """
        Initialize LoginPage with Playwright page instance.

        Args:
            page: Playwright page object
        """
        self.page = page

        # ── Locators ─────────────────────────────────────────────────────
        self.username_input = page.locator("input[name='username']")
        self.password_input = page.locator("input[name='password']")
        self.login_button = page.locator("button[type='submit']")
        self.error_message = page.locator(".oxd-alert-content--error")
        self.dashboard_header = page.locator("h6", has_text="Dashboard")

    def navigate(self):
        """Navigate to the OrangeHRM login page."""
        self.page.goto(self.URL, wait_until="networkidle")
        self.username_input.wait_for(state="visible")

    def login(self, username: str, password: str):
        """
        Log in to OrangeHRM with the given credentials.

        Args:
            username: The username to enter
            password: The password to enter
        """
        self.username_input.fill(username)
        self.password_input.fill(password)
        self.login_button.click()
        # Wait for either dashboard to load or error to appear
        self.page.wait_for_load_state("networkidle")

    def is_login_successful(self) -> bool:
        """
        Check if login was successful by verifying the Dashboard header.

        Returns:
            True if Dashboard header is visible, False otherwise
        """
        try:
            self.dashboard_header.wait_for(state="visible", timeout=10000)
            return True
        except Exception:
            return False

    def get_error_message(self) -> str:
        """
        Get the error message displayed on failed login.

        Returns:
            The text of the error message, or empty string if none
        """
        try:
            self.error_message.wait_for(state="visible", timeout=5000)
            return self.error_message.inner_text()
        except Exception:
            return ""

    def is_on_login_page(self) -> bool:
        """
        Check if the current page is the login page.

        Returns:
            True if on login page, False otherwise
        """
        return self.username_input.is_visible()
