"""
AdminPage - Page Object Model for OrangeHRM Admin / User Management Page.

Handles all interactions with the Admin module including:
- Navigating to Admin section
- Adding new users
- Searching for users
- Editing user details
- Deleting users
- Reading table data
"""


class AdminPage:
    """Page Object for the OrangeHRM Admin > User Management Page."""

    # ── URL ──────────────────────────────────────────────────────────────
    URL = "/web/index.php/admin/viewSystemUsers"

    def __init__(self, page):
        """
        Initialize AdminPage with Playwright page instance.

        Args:
            page: Playwright page object
        """
        self.page = page

        # ── Sidebar Navigation ───────────────────────────────────────────
        self.admin_menu = page.locator("a.oxd-main-menu-item", has_text="Admin")

        # ── Page Header ──────────────────────────────────────────────────
        self.page_title = page.locator(
            ".oxd-topbar-header-breadcrumb .oxd-text", has_text="Admin"
        )
        self.system_users_header = page.locator("h5", has_text="System Users")

        # ── Add User Button ──────────────────────────────────────────────
        self.add_button = page.locator("button.oxd-button--secondary", has_text="Add")

        # ── Search Form Fields ───────────────────────────────────────────
        # The search form has multiple input groups; we target by label relationship
        self.search_username_input = (
            page.locator("div.oxd-input-group")
            .filter(has_text="Username")
            .locator("input.oxd-input")
        )
        self.search_user_role_dropdown = (
            page.locator("div.oxd-input-group")
            .filter(has_text="User Role")
            .locator(".oxd-select-text")
        )
        self.search_status_dropdown = (
            page.locator("div.oxd-input-group")
            .filter(has_text="Status")
            .locator(".oxd-select-text")
        )
        self.search_button = page.locator(
            "button.oxd-button--secondary[type='submit']"
        )
        self.reset_button = page.locator(
            "button.oxd-button--ghost", has_text="Reset"
        )

        # ── User Table ───────────────────────────────────────────────────
        self.table_rows = page.locator(".oxd-table-body .oxd-table-row")
        self.no_records_text = page.locator(".oxd-text", has_text="No Records Found")
        self.records_found_text = page.locator(
            ".oxd-text", has_text="Record Found"
        )

        # ── Toast Notifications ──────────────────────────────────────────
        self.success_toast = page.locator(".oxd-toast--success")
        self.toast_message = page.locator(".oxd-toast-content .oxd-text--toast-message")

        # ── Delete Confirmation Dialog ───────────────────────────────────
        self.delete_confirm_button = page.locator(
            ".oxd-dialog-container button.oxd-button--label-danger",
            has_text="Yes, Delete",
        )

        # ── Add/Edit User Form Fields ────────────────────────────────────
        self.form_user_role_dropdown = (
            page.locator(".oxd-form .oxd-input-group")
            .filter(has_text="User Role")
            .locator(".oxd-select-text")
        )
        self.form_status_dropdown = (
            page.locator(".oxd-form .oxd-input-group")
            .filter(has_text="Status")
            .locator(".oxd-select-text")
        )
        self.form_employee_name_input = (
            page.locator(".oxd-form .oxd-input-group")
            .filter(has_text="Employee Name")
            .locator("input")
        )
        self.form_username_input = (
            page.locator(".oxd-form .oxd-input-group")
            .filter(has_text="Username")
            .locator("input.oxd-input")
        )
        self.form_password_input = (
            page.locator(".oxd-form .oxd-input-group")
            .filter(has_text="Password")
            .first.locator("input[type='password']")
        )
        self.form_confirm_password_input = (
            page.locator(".oxd-form .oxd-input-group")
            .filter(has_text="Confirm Password")
            .locator("input[type='password']")
        )
        self.form_save_button = page.locator(
            "button.oxd-button--secondary[type='submit']"
        )
        self.form_change_password_checkbox = page.locator(
            ".oxd-form .oxd-input-group"
        ).filter(has_text="Change Password").locator("input[type='checkbox']")
        self.autocomplete_dropdown = page.locator(
            ".oxd-autocomplete-dropdown .oxd-autocomplete-option"
        )

    # ── Navigation Methods ───────────────────────────────────────────────

    def navigate(self):
        """Navigate to Admin page via sidebar menu click."""
        self.admin_menu.click()
        self.page.wait_for_url("**/admin/viewSystemUsers**")
        self.page.wait_for_load_state("networkidle")

    def navigate_direct(self):
        """Navigate to Admin page directly via URL."""
        self.page.goto(self.URL, wait_until="networkidle")

    def is_on_admin_page(self) -> bool:
        """
        Check if the current page is the Admin page.

        Returns:
            True if Admin page is loaded with User Management visible
        """
        try:
            self.page_title.wait_for(state="visible", timeout=10000)
            return True
        except Exception:
            return False

    # ── Add User Methods ─────────────────────────────────────────────────

    def click_add_button(self):
        """Click the '+ Add' button to open the Add User form."""
        self.add_button.click()
        self.page.wait_for_url("**/admin/saveSystemUser**")
        self.page.wait_for_load_state("networkidle")

    def _select_dropdown_option(self, dropdown_locator, option_text: str):
        """
        Select an option from an OXD dropdown by visible text.

        Args:
            dropdown_locator: The Playwright locator for the dropdown trigger
            option_text: The visible text of the option to select
        """
        dropdown_locator.click()
        self.page.locator(
            ".oxd-select-dropdown .oxd-select-option",
            has_text=option_text,
        ).click()

    def _fill_employee_name(self, employee_name: str):
        """
        Fill the Employee Name autocomplete field and select the first suggestion.

        Args:
            employee_name: The employee name to search for
        """
        self.form_employee_name_input.clear()
        self.form_employee_name_input.fill(employee_name)
        # Wait for autocomplete suggestions to appear
        self.autocomplete_dropdown.first.wait_for(state="visible", timeout=10000)
        # Select the first matching suggestion
        self.autocomplete_dropdown.first.click()

    def add_user(
        self,
        user_role: str,
        employee_name: str,
        status: str,
        username: str,
        password: str,
    ):
        """
        Fill out and submit the Add User form.

        Args:
            user_role: 'Admin' or 'ESS'
            employee_name: Name of existing employee (for autocomplete)
            status: 'Enabled' or 'Disabled'
            username: Unique username for the new user
            password: Password for the new user
        """
        # Click the Add button
        self.click_add_button()

        # Fill form fields
        self._select_dropdown_option(self.form_user_role_dropdown, user_role)
        self._fill_employee_name(employee_name)
        self._select_dropdown_option(self.form_status_dropdown, status)

        self.form_username_input.fill(username)
        self.form_password_input.fill(password)
        self.form_confirm_password_input.fill(password)

        # Submit the form
        self.form_save_button.click()
        self.page.wait_for_load_state("networkidle")

    # ── Search Methods ───────────────────────────────────────────────────

    def search_user(self, username: str):
        """
        Search for a user by username using the search form.

        Args:
            username: The username to search for
        """
        # Make sure we are on the admin page
        self.page.wait_for_url("**/admin/viewSystemUsers**", timeout=10000)
        self.page.wait_for_load_state("networkidle")

        # Clear and fill the search username field
        self.search_username_input.clear()
        self.search_username_input.fill(username)

        # Click the search button
        self.search_button.click()
        self.page.wait_for_load_state("networkidle")
        # Give table a moment to refresh
        self.page.wait_for_timeout(1000)

    def get_search_results_count(self) -> int:
        """
        Get the number of rows in the search results table.

        Returns:
            Number of rows found, or 0 if 'No Records Found'
        """
        try:
            if self.no_records_text.is_visible():
                return 0
        except Exception:
            pass
        return self.table_rows.count()

    def is_no_records_found(self) -> bool:
        """
        Check if 'No Records Found' message is displayed.

        Returns:
            True if no records message is visible
        """
        try:
            self.no_records_text.wait_for(state="visible", timeout=5000)
            return True
        except Exception:
            return False

    # ── Table Data Methods ───────────────────────────────────────────────

    def get_user_row_data(self, row_index: int = 0) -> dict:
        """
        Get the data from a specific row in the users table.

        The OrangeHRM table columns are:
        [Checkbox] | Username | User Role | Employee Name | Status | Actions

        Args:
            row_index: The 0-based index of the row to read

        Returns:
            Dictionary with keys: username, user_role, employee_name, status
        """
        row = self.table_rows.nth(row_index)
        cells = row.locator(".oxd-table-cell")

        return {
            "username": cells.nth(1).inner_text().strip(),
            "user_role": cells.nth(2).inner_text().strip(),
            "employee_name": cells.nth(3).inner_text().strip(),
            "status": cells.nth(4).inner_text().strip(),
        }

    def get_first_user_data(self) -> dict:
        """
        Get data from the first row of the search results.

        Returns:
            Dictionary with user details from the first row
        """
        self.table_rows.first.wait_for(state="visible", timeout=10000)
        return self.get_user_row_data(0)

    # ── Edit User Methods ────────────────────────────────────────────────

    def click_edit_button(self, row_index: int = 0):
        """
        Click the Edit (pencil) button for a specific row.

        Args:
            row_index: The 0-based index of the row to edit
        """
        row = self.table_rows.nth(row_index)
        edit_button = row.locator(".oxd-icon.bi-pencil-fill").first
        edit_button.click()
        self.page.wait_for_url("**/admin/saveSystemUser/**")
        self.page.wait_for_load_state("networkidle")

    def edit_user(
        self,
        new_user_role: str = None,
        new_employee_name: str = None,
        new_status: str = None,
        new_username: str = None,
        new_password: str = None,
    ):
        """
        Edit user details on the Edit User form.

        Args:
            new_user_role: New role ('Admin' or 'ESS'), or None to keep current
            new_employee_name: New employee name, or None to keep current
            new_status: New status ('Enabled' or 'Disabled'), or None to keep current
            new_username: New username, or None to keep current
            new_password: New password, or None to keep current
        """
        # Change User Role if specified
        if new_user_role:
            self._select_dropdown_option(self.form_user_role_dropdown, new_user_role)

        # Change Employee Name if specified
        if new_employee_name:
            self._fill_employee_name(new_employee_name)

        # Change Status if specified
        if new_status:
            self._select_dropdown_option(self.form_status_dropdown, new_status)

        # Change Username if specified
        if new_username:
            self.form_username_input.clear()
            self.form_username_input.fill(new_username)

        # Change Password if specified
        if new_password:
            # Click the change password toggle first
            try:
                self.form_change_password_checkbox.check()
                self.page.wait_for_timeout(500)
            except Exception:
                pass  # Checkbox might not exist on add form
            self.form_password_input.fill(new_password)
            self.form_confirm_password_input.fill(new_password)

        # Submit the form
        self.form_save_button.click()
        self.page.wait_for_load_state("networkidle")

    # ── Delete User Methods ──────────────────────────────────────────────

    def click_delete_button(self, row_index: int = 0):
        """
        Click the Delete (trash) button for a specific row.

        Args:
            row_index: The 0-based index of the row to delete
        """
        row = self.table_rows.nth(row_index)
        delete_button = row.locator(".oxd-icon.bi-trash").first
        delete_button.click()

    def confirm_delete(self):
        """Click 'Yes, Delete' on the confirmation dialog."""
        self.delete_confirm_button.wait_for(state="visible", timeout=5000)
        self.delete_confirm_button.click()
        self.page.wait_for_load_state("networkidle")

    def delete_user(self, row_index: int = 0):
        """
        Delete a user by clicking delete and confirming.

        Args:
            row_index: The 0-based index of the row to delete
        """
        self.click_delete_button(row_index)
        self.confirm_delete()

    # ── Toast/Notification Methods ───────────────────────────────────────

    def wait_for_success_toast(self, timeout: int = 10000) -> bool:
        """
        Wait for a success toast notification to appear.

        Args:
            timeout: Maximum wait time in milliseconds

        Returns:
            True if success toast appeared
        """
        try:
            self.success_toast.wait_for(state="visible", timeout=timeout)
            return True
        except Exception:
            return False

    def get_toast_message(self) -> str:
        """
        Get the text of the toast notification message.

        Returns:
            The toast message text
        """
        try:
            self.toast_message.wait_for(state="visible", timeout=5000)
            return self.toast_message.inner_text().strip()
        except Exception:
            return ""
