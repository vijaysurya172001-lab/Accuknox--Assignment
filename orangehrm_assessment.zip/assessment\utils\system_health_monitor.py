#!/usr/bin/env python3
"""
System Health Monitor
=====================
A production-quality utility that monitors CPU, memory, and disk usage,
alerts when thresholds are exceeded, lists the top processes by CPU,
and optionally runs in continuous mode.

Dependencies:
    pip install psutil

Usage:
    python system_health_monitor.py
    python system_health_monitor.py --threshold 75
    python system_health_monitor.py --continuous --interval 10
"""

import argparse
import logging
import os
import sys
import time
from datetime import datetime

try:
    import psutil
except ImportError:
    print(
        "❌  Missing dependency: psutil\n"
        "   Install it with:  pip install psutil"
    )
    sys.exit(1)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DEFAULT_THRESHOLD = 80          # percent
DEFAULT_INTERVAL = 5            # seconds
LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "health.log")
TOP_N_PROCESSES = 5

BANNER = r"""
╔══════════════════════════════════════════════════╗
║          🖥️  System Health Monitor  🖥️           ║
╠══════════════════════════════════════════════════╣
║  Monitors CPU · Memory · Disk · Top Processes   ║
╚══════════════════════════════════════════════════╝
"""

# ---------------------------------------------------------------------------
# Logging setup – file handler only (console output is handled manually)
# ---------------------------------------------------------------------------

def _get_file_logger() -> logging.Logger:
    """Return a logger that appends alert lines to *health.log*."""
    logger = logging.getLogger("health_monitor")
    if not logger.handlers:
        logger.setLevel(logging.WARNING)
        fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
        fh.setLevel(logging.WARNING)
        fh.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(fh)
    return logger


file_logger = _get_file_logger()

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _timestamp() -> str:
    """Return a formatted timestamp string for the current moment."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _format_line(timestamp: str, icon: str, label: str, value: int,
                 threshold: int) -> str:
    """Build a single status line with emoji and threshold comparison."""
    if value > threshold:
        return (
            f"[{timestamp}] {icon}  ALERT: {label}: {value}% "
            f"— Exceeds {threshold}% threshold!"
        )
    return f"[{timestamp}] {icon} {label}: {value}% — Normal"


def _print_separator() -> None:
    """Print a thin visual separator."""
    print("─" * 55)

# ---------------------------------------------------------------------------
# Core monitoring functions
# ---------------------------------------------------------------------------

def check_cpu(threshold: int) -> dict:
    """
    Sample CPU usage over a 1-second interval.

    Returns:
        dict with keys 'label', 'value', 'alert', 'line'.
    """
    usage = psutil.cpu_percent(interval=1)
    ts = _timestamp()
    alert = usage > threshold
    icon = "⚠️" if alert else "✅"
    line = _format_line(ts, icon, "CPU Usage", int(usage), threshold)
    return {"label": "CPU Usage", "value": int(usage), "alert": alert, "line": line}


def check_memory(threshold: int) -> dict:
    """
    Check virtual-memory usage.

    Returns:
        dict with keys 'label', 'value', 'alert', 'line'.
    """
    mem = psutil.virtual_memory()
    usage = int(mem.percent)
    ts = _timestamp()
    alert = usage > threshold
    icon = "⚠️" if alert else "✅"
    line = _format_line(ts, icon, "Memory Usage", usage, threshold)
    return {"label": "Memory Usage", "value": usage, "alert": alert, "line": line}


def check_disk(threshold: int, path: str = "/") -> dict:
    """
    Check disk usage for the given mount *path* (defaults to root).

    On Windows the root is typically ``C:\\``.

    Returns:
        dict with keys 'label', 'value', 'alert', 'line'.
    """
    # Use the drive where this script lives, or fall back to C:\\ on Windows.
    if sys.platform == "win32":
        path = os.path.splitdrive(os.path.abspath(__file__))[0] + "\\"
    disk = psutil.disk_usage(path)
    usage = int(disk.percent)
    ts = _timestamp()
    alert = usage > threshold
    icon = "⚠️" if alert else "✅"
    line = _format_line(ts, icon, f"Disk Usage ({path})", usage, threshold)
    return {"label": f"Disk Usage ({path})", "value": usage, "alert": alert, "line": line}


def top_processes(n: int = TOP_N_PROCESSES) -> list[dict]:
    """
    Return the top *n* processes sorted by CPU usage (descending).

    Each entry is a dict with 'pid', 'name', 'cpu', 'memory'.
    Processes that have terminated or are inaccessible are silently skipped.
    """
    procs: list[dict] = []
    for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
        try:
            info = proc.info
            procs.append({
                "pid": info["pid"],
                "name": info["name"] or "<unknown>",
                "cpu": info["cpu_percent"] or 0.0,
                "memory": round(info["memory_percent"] or 0.0, 1),
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    procs.sort(key=lambda p: p["cpu"], reverse=True)
    return procs[:n]

# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------

def print_top_processes(procs: list[dict]) -> None:
    """Pretty-print the top-process table to the console."""
    print(f"\n📊  Top {len(procs)} Processes by CPU Usage:")
    _print_separator()
    print(f"  {'PID':<8} {'Name':<28} {'CPU%':>6}  {'MEM%':>6}")
    _print_separator()
    for p in procs:
        name = (p['name'][:25] + '...') if len(p['name']) > 28 else p['name']
        print(f"  {p['pid']:<8} {name:<28} {p['cpu']:>5.1f}%  {p['memory']:>5.1f}%")
    _print_separator()

# ---------------------------------------------------------------------------
# Main orchestration
# ---------------------------------------------------------------------------

def run_health_check(threshold: int) -> None:
    """
    Execute a single health-check cycle:
      1. Check CPU, memory, and disk.
      2. Print results to the console.
      3. Log any alerts to *health.log*.
      4. Print the top-process table.
    """
    print(f"\n🕐  Health Check at {_timestamp()}")
    _print_separator()

    results = [
        check_cpu(threshold),
        check_memory(threshold),
        check_disk(threshold),
    ]

    for r in results:
        print(r["line"])
        if r["alert"]:
            file_logger.warning(r["line"])

    procs = top_processes()
    print_top_processes(procs)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse and return command-line arguments."""
    parser = argparse.ArgumentParser(
        description="🖥️  System Health Monitor — track CPU, memory & disk usage.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--threshold", "-t",
        type=int,
        default=DEFAULT_THRESHOLD,
        metavar="PCT",
        help=f"Alert threshold in %% (default: {DEFAULT_THRESHOLD}%%)",
    )
    parser.add_argument(
        "--interval", "-i",
        type=int,
        default=DEFAULT_INTERVAL,
        metavar="SEC",
        help=f"Seconds between checks in continuous mode (default: {DEFAULT_INTERVAL}s)",
    )
    parser.add_argument(
        "--continuous", "-c",
        action="store_true",
        help="Run continuously until interrupted (Ctrl+C to stop)",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    """Entry-point for the System Health Monitor."""
    args = parse_args(argv)

    print(BANNER)
    print(f"  Threshold : {args.threshold}%")
    print(f"  Interval  : {args.interval}s")
    print(f"  Mode      : {'Continuous' if args.continuous else 'Single run'}")
    print(f"  Log file  : {LOG_FILE}")
    _print_separator()

    if args.continuous:
        print("\n🔄  Continuous mode — press Ctrl+C to stop.\n")
        try:
            while True:
                run_health_check(args.threshold)
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n\n👋  Monitoring stopped by user. Goodbye!")
    else:
        run_health_check(args.threshold)
        print(f"\n✅  Single check complete. Alerts (if any) saved to {LOG_FILE}")


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    main()
